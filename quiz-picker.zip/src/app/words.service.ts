import { Injectable } from '@angular/core';
import { Wordtype } from './data/wordtype';
import { WORDBASE } from './data/wordbase';

@Injectable({
  providedIn: 'root',
})
export class WordsService {
  constructor() {}

  getWords() {
    return WORDBASE;
  }
}
