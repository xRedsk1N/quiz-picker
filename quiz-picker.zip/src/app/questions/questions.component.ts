import { Component } from '@angular/core';
import { WordsService } from '../words.service';
import { Wordtype } from '../data/wordtype';

@Component({
  selector: 'app-questions',
  templateUrl: './questions.component.html',
  styleUrls: ['./questions.component.css'],
})
export class QuestionsComponent {
  constructor(private WordsService: WordsService) {}

  Questions: Wordtype[] = this.WordsService.getWords();
  AnswersZw: Wordtype[] = [];
  AnswersRo: Wordtype[] = [];
  amount = this.Questions.length;
  chosen?: Wordtype;
  i: number = 0;
  clicked: boolean = false;

  AddZwierz() {
    this.chosen = this.Questions[this.i];
    this.chosen.current = 'ZWIERZ';

    this.AnswersZw.push(this.chosen);
    if (this.i < this.amount) this.i += 1;
  }

  AddRoslina() {
    this.chosen = this.Questions[this.i];
    this.chosen.current = 'ROSLINA';

    this.AnswersRo.push(this.chosen);
    if (this.i < this.amount) this.i += 1;
  }

  check() {
    this.clicked = true;
  }
}
