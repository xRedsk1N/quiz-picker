export interface Wordtype {
  type: 'ZWIERZ' | 'ROSLINA';
  name: string;
  current?: 'ZWIERZ' | 'ROSLINA';
}
