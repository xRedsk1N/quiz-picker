import { Wordtype } from './wordtype';

export const WORDBASE: Wordtype[] = [
  { type: 'ZWIERZ', name: 'Słoń', current: undefined },
  { type: 'ROSLINA', name: 'Kaktus', current: undefined },
  { type: 'ZWIERZ', name: 'Niedźwiedz', current: undefined },
  { type: 'ZWIERZ', name: 'Orzeł', current: undefined },
  { type: 'ROSLINA', name: 'Paprotka', current: undefined },
  { type: 'ROSLINA', name: 'Muchołówka', current: undefined },
  { type: 'ROSLINA', name: 'Klon', current: undefined },
  { type: 'ZWIERZ', name: 'Wilk', current: undefined },
  { type: 'ROSLINA', name: 'Stokrotka', current: undefined },
  { type: 'ZWIERZ', name: 'Łoś', current: undefined },
];
