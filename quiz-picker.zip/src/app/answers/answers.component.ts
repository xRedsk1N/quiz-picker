import { Component, Input } from '@angular/core';
import { Wordtype } from '../data/wordtype';
import { WordsService } from '../words.service';

@Component({
  selector: 'app-answers',
  templateUrl: './answers.component.html',
  styleUrls: ['./answers.component.css'],
})
export class AnswersComponent {
  @Input() answersZwierzeta: Wordtype[] = [];
  @Input() answersRosliny: Wordtype[] = [];

  corrColor: string = '#008f11';
  uncorrColor: string = '#8f000a';

  isAnswerCorrect(target: Wordtype) {
    return target.current == target.type;
  }

  reloadPage() {
    window.location.reload();
  }
}
