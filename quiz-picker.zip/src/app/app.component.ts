import { Component } from '@angular/core';
import { WordsService } from './words.service';
import { Wordtype } from './data/wordtype';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  constructor(private WordsService: WordsService) {}
  title = 'quiz-picker';
}
